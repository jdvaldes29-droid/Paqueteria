import flet as ft
from login import login_view
from paquetes import paquetes_view
from supabase_client import supabase
import threading
import time
import random

# -------- GPS (simulado en PC) --------
def obtener_ubicacion():
    """
    En Android: aquí Flet obtiene GPS real.
    En PC: simulamos coordenadas.
    """
    lat = 19.4326 + random.uniform(-0.01, 0.01)
    lon = -99.1332 + random.uniform(-0.01, 0.01)
    return lat, lon

def iniciar_envio_gps(user):
    def loop():
        while True:
            try:
                # obtener repartidor_id
                user_db = supabase.table("usuarios") \
                    .select("repartidor_id") \
                    .eq("email", user.email) \
                    .single() \
                    .execute()

                repartidor_id = user_db.data["repartidor_id"]

                lat, lon = obtener_ubicacion()

                supabase.table("ubicaciones").insert({
                    "repartidor_id": repartidor_id,
                    "latitud": lat,
                    "longitud": lon
                }).execute()

                print(f"GPS enviado: {lat}, {lon}")

            except Exception as e:
                print("Error GPS:", e)

            time.sleep(60)  # cada 60 segundos

    threading.Thread(target=loop, daemon=True).start()

# -------- APP --------
def main(page: ft.Page):
    page.title = "Paquetería – Repartidor"
    page.horizontal_alignment = "center"
    page.vertical_alignment = "center"

    def on_login_success(user):
        # iniciar GPS al loguear
        iniciar_envio_gps(user)

        page.clean()
        page.add(paquetes_view(page, user))

    page.add(login_view(page, on_login_success))

ft.app(target=main)