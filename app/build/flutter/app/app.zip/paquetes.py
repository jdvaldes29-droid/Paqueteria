import flet as ft
from supabase_client import supabase
import uuid
import datetime

def paquetes_view(page: ft.Page, user):

    # --- obtener repartidor ---
    user_db = supabase.table("usuarios") \
        .select("*") \
        .eq("email", user.email) \
        .single() \
        .execute()

    if not user_db.data or user_db.data["rol"] != "REPARTIDOR":
        return ft.Text("Usuario no autorizado")

    repartidor_id = user_db.data["repartidor_id"]

    # --- helpers ---
    def subir_foto_y_entregar(paquete_id, quien_recibe, archivo):
        # nombre único del archivo
        nombre_archivo = f"{paquete_id}/{uuid.uuid4()}.jpg"

        # subir a storage
        supabase.storage.from_("evidencias").upload(
            nombre_archivo,
            archivo,
            {"content-type": "image/jpeg"}
        )

        # obtener URL pública
        foto_url = supabase.storage.from_("evidencias") \
            .get_public_url(nombre_archivo)

        # registrar entrega
        supabase.table("entregas").insert({
            "paquete_id": paquete_id,
            "quien_recibe": quien_recibe,
            "foto_url": foto_url,
            "fecha_entrega": datetime.datetime.utcnow().isoformat()
        }).execute()

        # actualizar estatus
        supabase.table("paquetes") \
            .update({"estatus": "ENTREGADO"}) \
            .eq("id", paquete_id) \
            .execute()

        page.snack_bar = ft.SnackBar(ft.Text("Entrega registrada"))
        page.snack_bar.open = True

        page.clean()
        page.add(paquetes_view(page, user))
        page.update()

    # --- UI para cada paquete ---
    def tarjeta_paquete(p):
        nombre_recibe = ft.TextField(label="Quién recibe", width=250)

        def seleccionar_foto(e):
            def on_file_result(result: ft.FilePickerResultEvent):
                if result.files:
                    with open(result.files[0].path, "rb") as f:
                        subir_foto_y_entregar(
                            p["id"],
                            nombre_recibe.value,
                            f.read()
                        )

            picker = ft.FilePicker(on_result=on_file_result)
            page.overlay.append(picker)
            page.update()
            picker.pick_files(allow_multiple=False)

        return ft.Card(
            content=ft.Column(
                [
                    ft.Text(p["direccion"], weight="bold"),
                    ft.Text(f"Estatus: {p['estatus']}"),
                    nombre_recibe,
                    ft.ElevatedButton(
                        "📸 Entregar con foto",
                        on_click=seleccionar_foto
                    )
                ],
                spacing=8
            )
        )

    # --- obtener paquetes ---
    paquetes = supabase.table("paquetes") \
        .select("*") \
        .eq("repartidor_id", repartidor_id) \
        .execute().data

    items = [tarjeta_paquete(p) for p in paquetes] if paquetes else [ft.Text("No tienes paquetes")]

    return ft.Column(
        [
            ft.Text("Mis Paquetes", size=20, weight="bold"),
            ft.Column(items, scroll=ft.ScrollMode.AUTO)
        ],
        expand=True
    )