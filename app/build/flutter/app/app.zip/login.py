import flet as ft
from supabase_client import supabase

def login_view(page: ft.Page, on_success):

    email = ft.TextField(label="Correo", width=300)
    password = ft.TextField(label="Contraseña", password=True, width=300)
    error_text = ft.Text(color="red")

    def do_login(e):
        try:
            res = supabase.auth.sign_in_with_password({
                "email": email.value,
                "password": password.value
            })
            on_success(res.user)
        except Exception as ex:
            error_text.value = "Credenciales incorrectas"
            page.update()

    return ft.Column(
        [
            ft.Text("Ingreso Repartidor", size=22, weight="bold"),
            email,
            password,
            ft.ElevatedButton("Entrar", on_click=do_login),
            error_text,
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER
    )